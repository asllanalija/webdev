NAME = 0, INFO = 1, IMAGE = 2;

pageTitle = "Dragons";

items = "Blackbox:asdjhafha:blackbox.png;initialize:asdasdasd:initialize.png;itemArray:asdasdasdas:itemArray.png;itemdata:asadsadas:itemdata.png;itemList:asdhuashdas:itemList.png;thebody:ashduhasjd:thebody.png"