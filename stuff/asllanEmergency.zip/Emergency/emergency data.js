EMERGENCY_TYPES = ["Cat in a Tree", "Car Accident", "Fire", "Building Collapse", "Gas Leak"];
EMERGENCY_ICONS = ["cat.png", "car accident.png", "icon-flame.png", "building collapse.png", "gas leak.png"];
